package com.example.dabang.ui

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.NoMatchingViewException
import androidx.test.espresso.ViewAssertion
import androidx.test.espresso.matcher.ViewMatchers
import org.hamcrest.CoreMatchers
import java.lang.IllegalStateException

/**
 * Created by JEONGWOOKIM on 2020-03-11.
 * Description:
 */
class CustomAssertions {

    companion object{
        fun hasItemCount(count: Int) : ViewAssertion{
            return RecyclerViewItemCountAssertion(count)
        }
    }

    private class RecyclerViewItemCountAssertion(private val count: Int) : ViewAssertion{

        override fun check(view: View?, noViewFoundException: NoMatchingViewException?) {
            if(noViewFoundException != null){
                throw noViewFoundException
            }

            if(view !is RecyclerView){
                throw IllegalStateException("This asserted view is not RecyclerView")
            }

            if(view.adapter == null){
                throw IllegalStateException("No adapter is assigned to RecyclerView")
            }

            ViewMatchers.assertThat("RecyclerView item count", view.adapter!!.itemCount, CoreMatchers.equalTo(count))

        }
    }

}