package com.example.dabang

import android.content.Context
import androidx.test.filters.SdkSuppress
import androidx.test.filters.LargeTest
import org.junit.Assert.*
import org.junit.runner.*
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.platform.app.InstrumentationRegistry
import com.example.dabang.api.RoomSearchResponse
import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import com.google.gson.Gson
import org.junit.Before
import org.junit.Test
import java.io.InputStream
import java.nio.charset.Charset

/**
 * Created by JEONGWOOKIM on 2020-03-10.
 * Description:
 */

class SimpleAndroidTest {

    private val gson: Gson = Gson()
    private lateinit var jsonData: String
    private val context: Context = InstrumentationRegistry.getInstrumentation().context

    @Before
    fun setup(){
        parsingDataTest()
    }

    @Test
    fun parsingDataTest(){
        val inputStream: InputStream = context.resources.assets.open("rooms.json")
        val fileSize: Int = inputStream.available()

        val buffer = ByteArray(fileSize)
        inputStream.read(buffer)
        inputStream.close()

        jsonData = String(buffer, Charset.forName("UTF-8"))

        assertTrue(jsonData.isNotEmpty())
    }

    @Test
    fun jsonToRoomSearchResponse(){
        val roomSearchResponse : RoomSearchResponse =
            gson.fromJson(jsonData, RoomSearchResponse::class.java)

        assertTrue(roomSearchResponse.rooms.size == 100)
        assertTrue(roomSearchResponse.average.size == 1)
    }

    @Test
    fun filterTest(){
        val roomSearchResponse : RoomSearchResponse =
            gson.fromJson(jsonData, RoomSearchResponse::class.java)

        var roomTypes: Array<RoomType> = arrayOf(RoomType.ONE, RoomType.TWO, RoomType.OFFICETEL, RoomType.APT)
        var sellingTypes: Array<SellingType> = arrayOf(SellingType.MONTH, SellingType.YEAR, SellingType.SELL)

        roomSearchResponse.rooms =
            roomSearchResponse.rooms
                .filter { rooms ->
                    roomTypes.contains(rooms.room_type) && sellingTypes.contains(rooms.selling_type)
                }

        assertTrue(roomSearchResponse.rooms.size == 100)
    }
}