package com.example.dabang.ui

import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.*
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.*
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.filters.SdkSuppress
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import com.example.dabang.R
import kotlinx.android.synthetic.main.activity_search_room.*
import kotlinx.android.synthetic.main.custom_room_filter_view.view.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Created by JEONGWOOKIM on 2020-03-11.
 * Description:
 */

@RunWith(AndroidJUnit4ClassRunner::class)
@SdkSuppress(minSdkVersion = 18)
@LargeTest
class SearchRoomActivityTest{

    companion object{
        const val ONE_ROOM_ITEM_COUNT = 28
        const val LIST_ITEM_COUNT = 101
    }

    @get:Rule
    var activityRule: ActivityTestRule<SearchRoomActivity> = ActivityTestRule(SearchRoomActivity::class.java)

    @Test
    fun recyclerViewScrollAndFilteredItemCountTest(){
        for(i in 1..8){
            onView(withId(R.id.room_recycler_view)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                activityRule.activity.findViewById<RecyclerView>(R.id.room_recycler_view).adapter!!.itemCount -1
            ))
        }

        onView(withId(R.id.room_recycler_view)).check(CustomAssertions.hasItemCount(LIST_ITEM_COUNT))

        onView(withId(R.id.filter_room_type_one_room_btn))
            .perform(click())

        for(i in 1..8){
            onView(withId(R.id.room_recycler_view)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                activityRule.activity.findViewById<RecyclerView>(R.id.room_recycler_view).adapter!!.itemCount -1
            ))
        }
        onView(withId(R.id.room_recycler_view)).check(CustomAssertions.hasItemCount(LIST_ITEM_COUNT-ONE_ROOM_ITEM_COUNT))
    }

    @Test
    fun filterClickTest(){
        //방타입 클릭
        onView(withId(R.id.filter_room_type_one_room_btn))
            .perform(click())
        onView(withId(R.id.filter_room_type_one_room_btn)).check(matches(hasTextColor(R.color.filterUnCheckedButtonTextColor)))

        onView(withId(R.id.filter_room_type_two_room_btn))
            .perform(click())
        onView(withId(R.id.filter_room_type_two_room_btn)).check(matches(hasTextColor(R.color.filterUnCheckedButtonTextColor)))

        onView(withId(R.id.filter_room_type_officetel_btn))
            .perform(click())
        onView(withId(R.id.filter_room_type_officetel_btn)).check(matches(hasTextColor(R.color.filterUnCheckedButtonTextColor)))

        onView(withId(R.id.filter_room_type_apt_btn))
            .perform(click())
        onView(withId(R.id.filter_room_type_apt_btn)).check(matches(hasTextColor(R.color.filterCheckedButtonTextColor)))


        //판매타입 클릭
        onView(withId(R.id.filter_selling_type_monthly_btn))
            .perform(click())
        onView(withId(R.id.filter_selling_type_monthly_btn)).check(matches(hasTextColor(R.color.filterUnCheckedButtonTextColor)))

        onView(withId(R.id.filter_selling_type_yearly_btn))
            .perform(click())
        onView(withId(R.id.filter_selling_type_yearly_btn)).check(matches(hasTextColor(R.color.filterUnCheckedButtonTextColor)))

        onView(withId(R.id.filter_selling_type_sell_btn))
            .perform(click())
        onView(withId(R.id.filter_selling_type_sell_btn)).check(matches(hasTextColor(R.color.filterCheckedButtonTextColor)))

    }

}