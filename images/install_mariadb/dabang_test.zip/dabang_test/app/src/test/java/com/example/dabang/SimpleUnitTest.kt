package com.example.dabang

import android.content.Context
import androidx.arch.core.executor.ArchTaskExecutor
import androidx.arch.core.executor.TaskExecutor
import com.example.dabang.api.RoomService
import com.example.dabang.api.RoomServiceImpl
import com.example.dabang.data.RoomRepository
import com.example.dabang.di.repositoryModule
import com.example.dabang.di.serviceModule
import com.example.dabang.di.viewModelModule
import com.example.dabang.ui.SearchRoomViewModel
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin
import org.koin.test.KoinTest
import org.mockito.Mockito.mock

class SimpleUnitTest : KoinTest {

    private lateinit var roomService: RoomService
    private lateinit var roomRepository: RoomRepository
    private lateinit var viewModel: SearchRoomViewModel
    private lateinit var context: Context

    @Before
    fun before() {
        startKoin {
            modules(listOf(
                serviceModule,
                repositoryModule,
                viewModelModule
            ))
        }

        context = mock(Context::class.java)

        ArchTaskExecutor.getInstance().setDelegate(object : TaskExecutor() {
            override fun executeOnDiskIO(runnable: Runnable) = runnable.run()
            override fun isMainThread(): Boolean = true
            override fun postToMainThread(runnable: Runnable) = runnable.run()
        })

        roomService = RoomServiceImpl(context)
        roomRepository = RoomRepository(roomService)
        viewModel = SearchRoomViewModel(roomRepository)
    }

    @Test
    fun roomServiceIsNotNull() {
        assertNotNull(roomService)
    }

    @Test
    fun roomRepositoryIsNotNull(){
        assertNotNull(roomRepository)
    }

    @Test
    fun roomViewModelIsNotNull(){
        assertNotNull(viewModel)
    }

    @Test
    fun pagingTest() {
        val list: List<Int> = List(100) { i ->
            i
        }
        assertEquals(list.size, 100)

        val page: Int = 2
        val perPage: Int = 12

        val newList: List<Int> =
            list.filter { i -> i >= (page - 1) * perPage && i < page * perPage }
        assertEquals(newList.size, 12)

        val targetList: List<Int> = arrayListOf(12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23)
        assertArrayEquals(newList.toIntArray(), targetList.toIntArray())
    }

    @After
    fun after() {
        ArchTaskExecutor.getInstance().setDelegate(null)
        stopKoin()
    }
}
