package com.example.dabang.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.dabang.R
import com.example.dabang.data.PARSING_PAGE_SIZE
import com.example.dabang.data.RoomType
import com.example.dabang.databinding.RoomAvgItemBinding
import com.example.dabang.databinding.RoomViewType1ItemBinding
import com.example.dabang.databinding.RoomViewType2ItemBinding
import com.example.dabang.model.Average
import com.example.dabang.model.Room
import com.example.dabang.ui.base.BaseViewHolder

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방정보 recyclerview adapter
 */
class RoomsAdapter(var rooms: List<Room>, var averages: List<Average>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when(viewType){
            ROOM_ITEM_TYPE -> createRoomTypeViewHolder(parent)
            APT_ITEM_TYPE  -> createAptTypeViewHolder(parent)
            AVG_ITEM_TYPE  -> createAvgTypeViewHolder(parent)
            else -> createRoomTypeViewHolder(parent)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is RoomsItemRoomTypeViewHolder -> {
                holder.viewDataBinding.room = rooms[position]
            }
            is RoomsItemAptTypeViewHolder -> {
                holder.viewDataBinding.room = rooms[position]
            }
            is RoomsItemAvgTypeViewHolder -> {
                holder.viewDataBinding.average = averages.firstOrNull()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return if(itemCount <= PARSING_PAGE_SIZE && position == itemCount-1) AVG_ITEM_TYPE
        else{
            if(position == PARSING_PAGE_SIZE) AVG_ITEM_TYPE
            else{
                when(rooms[position].room_type){
                    RoomType.ONE, RoomType.TWO -> ROOM_ITEM_TYPE
                    RoomType.OFFICETEL, RoomType.APT -> APT_ITEM_TYPE
                }
            }
        }
    }

    override fun getItemCount(): Int = rooms.size

    class RoomsItemRoomTypeViewHolder(view: View) : BaseViewHolder<RoomViewType1ItemBinding>(view)
    class RoomsItemAptTypeViewHolder(view: View) : BaseViewHolder<RoomViewType2ItemBinding>(view)
    class RoomsItemAvgTypeViewHolder(view: View) : BaseViewHolder<RoomAvgItemBinding>(view)

    companion object {
        const val ROOM_ITEM_TYPE: Int = 0
        const val APT_ITEM_TYPE: Int = 1
        const val AVG_ITEM_TYPE: Int = 2

        fun createRoomTypeViewHolder(parent: ViewGroup): RoomsItemRoomTypeViewHolder{
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.room_view_type1_item,parent,false)
            return RoomsItemRoomTypeViewHolder(view)
        }

        fun createAptTypeViewHolder(parent: ViewGroup): RoomsItemAptTypeViewHolder{
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.room_view_type2_item,parent,false)
            return RoomsItemAptTypeViewHolder(view)
        }

        fun createAvgTypeViewHolder(parent: ViewGroup): RoomsItemAvgTypeViewHolder{
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.room_avg_item,parent,false)
            return RoomsItemAvgTypeViewHolder(view)
        }

    }

}