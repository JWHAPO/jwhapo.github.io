package com.example.dabang.ui.customview

import android.content.Context
import android.content.res.TypedArray
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View.OnClickListener
import androidx.appcompat.widget.AppCompatButton
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.dabang.R
import com.example.dabang.data.SellingType
import com.example.dabang.ui.SearchRoomViewModel
import com.example.dabang.ui.base.BaseViewModel
import com.example.dabang.util.style.CheckedFilterButtonStyleHolder
import com.example.dabang.util.style.StyleHolder
import com.example.dabang.util.style.UnCheckedFilterButtonStyleHolder

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 매물종류 layout custom view
 */
class SellingFilterView constructor(context: Context, attrs: AttributeSet) : ConstraintLayout(context, attrs) {
    private val filterSellingTypeMonthlyBtn: AppCompatButton
    private val filterSellingTypeYearlyBtn: AppCompatButton
    private val filterSellingTypeSellBtn: AppCompatButton
    private val checkedFilterButtonStyleHolder: StyleHolder<AppCompatButton> = CheckedFilterButtonStyleHolder(context)
    private val unCheckedFilterButtonStyleHolder: StyleHolder<AppCompatButton> = UnCheckedFilterButtonStyleHolder(context)

    private lateinit var searchRoomViewModel: SearchRoomViewModel

    init {
        val layoutInflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = layoutInflater.inflate(R.layout.custom_selling_filter_view, this, false)
        addView(view)

        filterSellingTypeMonthlyBtn = findViewById(R.id.filter_selling_type_monthly_btn)
        filterSellingTypeYearlyBtn = findViewById(R.id.filter_selling_type_yearly_btn)
        filterSellingTypeSellBtn = findViewById(R.id.filter_selling_type_sell_btn)

        initListener()
        getAttrs(attrs)
    }

    private fun initListener() {
        filterSellingTypeMonthlyBtn.setOnClickListener(onClickListener())
        filterSellingTypeYearlyBtn.setOnClickListener(onClickListener())
        filterSellingTypeSellBtn.setOnClickListener(onClickListener())
    }

    private fun onClickListener() : OnClickListener{
        return OnClickListener {view ->
            when(view.id){
                R.id.filter_selling_type_monthly_btn -> changeSellingFilter(SellingType.MONTH, filterSellingTypeMonthlyBtn)
                R.id.filter_selling_type_yearly_btn -> changeSellingFilter(SellingType.YEAR, filterSellingTypeYearlyBtn)
                R.id.filter_selling_type_sell_btn -> changeSellingFilter(SellingType.SELL, filterSellingTypeSellBtn)
            }
        }
    }

    private fun changeSellingFilter(sellingType: SellingType, button: AppCompatButton) {
        val sellingTypes = this.searchRoomViewModel.filters.value.sellingFilters

        if (sellingTypes.contains(sellingType)) {
            if(sellingTypes.size == 1) return

            unCheckedFilterButtonStyleHolder.applyStyle(button)
            this.searchRoomViewModel.setSellingFilters(sellingTypes.filter { it != sellingType }.toTypedArray())
        } else {
            checkedFilterButtonStyleHolder.applyStyle(button)
            this.searchRoomViewModel.setSellingFilters(sellingTypes.plus(sellingType))
        }
    }

    private fun getAttrs(attrs: AttributeSet){
        val typedArray: TypedArray = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.SellingFilterView, 0, 0
        )
        setTypedArray(typedArray)
    }

    private fun setTypedArray(typedArray: TypedArray) {
        typedArray.recycle()
    }

    fun setSellingTypes(viewModel: BaseViewModel) {
        if(viewModel is SearchRoomViewModel) this.searchRoomViewModel = viewModel
    }

}