package com.example.dabang.model

import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import com.google.gson.annotations.SerializedName

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 정보
 */
data class Room(
    @field:SerializedName("desc") val desc: String,
    @field:SerializedName("hash_tags") val hash_tags: List<String>,
    @field:SerializedName("img_url") val img_url: String,
    @field:SerializedName("is_check") val is_check: Boolean,
    @field:SerializedName("price_title") val price_title: String,
    @field:SerializedName("room_type") val room_type: RoomType,
    @field:SerializedName("selling_type") val selling_type: SellingType
){
    constructor() : this("", arrayListOf(""),"",false,"",RoomType.ONE,SellingType.MONTH)
}