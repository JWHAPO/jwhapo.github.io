package com.example.dabang.util.style

import android.view.View

/**
 * Created by JEONGWOOKIM on 2020-03-10.
 * Description:
 */
interface StyleHolder<in V: View> {
    fun applyStyle(view: V)
    fun setMargins(view: V, left:Int, top:Int, right:Int, bottom:Int)
}