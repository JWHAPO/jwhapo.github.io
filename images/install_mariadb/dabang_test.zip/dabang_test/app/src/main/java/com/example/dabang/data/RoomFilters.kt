package com.example.dabang.data

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 검색필터
 */
data class RoomFilters(
    var roomFilters: Array<RoomType>,
    var sellingFilters: Array<SellingType>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as RoomFilters

        if (!roomFilters.contentEquals(other.roomFilters)) return false
        if (!sellingFilters.contentEquals(other.sellingFilters)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = roomFilters.contentHashCode()
        result = 31 * result + sellingFilters.contentHashCode()
        return result
    }
}