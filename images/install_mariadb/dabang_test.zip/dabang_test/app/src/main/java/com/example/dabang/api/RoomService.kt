package com.example.dabang.api

import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import io.reactivex.Single

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 검색 서비스
 */
interface RoomService {
    fun searchRooms(
        roomTypes: Array<RoomType>,
        sellingTypes: Array<SellingType>,
        page: Int,
        perPage: Int
    ): Single<RoomSearchResponse>

    fun getTotalCount(
        roomTypes: Array<RoomType>,
        sellingTypes: Array<SellingType>
    ): Single<Int>
}