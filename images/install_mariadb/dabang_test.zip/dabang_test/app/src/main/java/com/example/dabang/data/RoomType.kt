package com.example.dabang.data

import com.example.dabang.MainApplication
import com.example.dabang.R
import com.google.gson.annotations.SerializedName

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 종류
 */
enum class RoomType(private val stringResourceId: Int) {
    @SerializedName("0") ONE(R.string.room_type_0),
    @SerializedName("1") TWO(R.string.room_type_1),
    @SerializedName("2") OFFICETEL(R.string.room_type_2),
    @SerializedName("3") APT(R.string.room_type_3);

    override fun toString(): String {
        return MainApplication.instance.applicationContext.getString(stringResourceId)
    }



}