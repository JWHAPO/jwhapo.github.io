package com.example.dabang.model

import androidx.lifecycle.LiveData

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 검색 결과정보
 */
data class RoomSearchResult(
    var averages: LiveData<List<Average>>,
    var rooms: LiveData<List<Room>>,
    var parsingErrors: LiveData<String>?
)