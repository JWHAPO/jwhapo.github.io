package com.example.dabang.util.style

import android.content.Context
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import com.example.dabang.R

/**
 * Created by JEONGWOOKIM on 2020-03-10.
 * Description:
 */


class CheckedFilterButtonStyleHolder(context: Context) : StyleHolder<Button>{

    private val background: Drawable
    private val textColor: Int
    private val textSize: Float
    private val padding:Int
    private val minWidth:Int
    private val minHeight:Int
    private val marginTop:Int
    private val marginLeft:Int

    init {
        val typeArray = context.obtainStyledAttributes(R.style.filter_checked_button, R.styleable.checkedFilterButtonStyleHolder)
        val resources: Resources = context.resources

        textColor = typeArray.getColor(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_textColor),ContextCompat.getColor(context, R.color.filterCheckedButtonTextColor))
        background = typeArray.getDrawable(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_background))?: ContextCompat.getDrawable(context, R.drawable.filter_checked_button_background)!!

        textSize = typeArray.getDimension(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_textSize),
            resources.getDimension(R.dimen.filterButtonTextSize))
        padding = typeArray.getDimensionPixelSize(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_padding),
            resources.getDimensionPixelSize(R.dimen.filterPaddingSize))
        minWidth = typeArray.getDimensionPixelSize(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_minWidth),
            resources.getDimensionPixelSize(R.dimen.filterButtonMinWidth))
        minHeight = typeArray.getDimensionPixelSize(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_minHeight),
            resources.getDimensionPixelSize(R.dimen.filterButtonMinHeight))
        marginTop = typeArray.getDimensionPixelSize(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_layout_marginTop),
            resources.getDimensionPixelSize(R.dimen.filterPaddingSize))
        marginLeft = typeArray.getDimensionPixelSize(typeArray.getIndex(R.styleable.checkedFilterButtonStyleHolder_android_layout_marginLeft),
            resources.getDimensionPixelSize(R.dimen.filterPaddingSize))

    }
    override fun applyStyle(view: Button) {
        view.background = background
        view.setTextColor(textColor)
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize)
        view.setPadding(padding)
        view.minWidth = minWidth
        view.minHeight = minHeight
        setMargins(view, marginLeft, marginTop,0,0)
    }

    override fun setMargins(view: Button, left: Int, top: Int, right: Int, bottom: Int) {
        if(view.layoutParams is ViewGroup.MarginLayoutParams){
            val params: ViewGroup.MarginLayoutParams = view.layoutParams as ViewGroup.MarginLayoutParams
            params.setMargins(left,top, right, bottom)
            view.requestLayout()
        }
    }
}