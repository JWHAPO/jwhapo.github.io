package com.example.dabang.ui.customview

import android.content.Context
import android.content.res.TypedArray
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.appcompat.widget.AppCompatTextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.dabang.R

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: hash tag text view custom view
 */
class HashTagTextView constructor(context: Context, attrs: AttributeSet?) :
    ConstraintLayout(context, attrs) {

    private lateinit var hashTagTv: AppCompatTextView

    init {
        initView()
        getAttrs(attrs)
    }

    private fun initView() {
        val layoutInflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = layoutInflater.inflate(R.layout.hash_tag_textview, this, false)
        addView(view)

        hashTagTv = findViewById(R.id.hash_tag_tv)
    }

    private fun getAttrs(attrs: AttributeSet?) {

        val typedArray: TypedArray = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.HashTagTextView, 0, 0
        )
        setTypedArray(typedArray)
    }

    private fun setTypedArray(typedArray: TypedArray) {
        val hashTagTextViewResId = typedArray.getString(R.styleable.HashTagTextView_text)

        hashTagTv.text = hashTagTextViewResId
        typedArray.recycle()
    }

    fun setText(text: String) {
        hashTagTv.text = text
    }

}