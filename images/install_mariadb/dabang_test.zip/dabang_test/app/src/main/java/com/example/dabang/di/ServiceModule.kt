package com.example.dabang.di

import com.example.dabang.api.RoomService
import com.example.dabang.api.RoomServiceImpl
import org.koin.android.ext.koin.androidContext
import org.koin.dsl.module

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description:
 */

val serviceModule = module {
    single<RoomService>(createdAtStart = false) { RoomServiceImpl(androidContext()) }
}