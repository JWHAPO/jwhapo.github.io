package com.example.dabang.util

import com.bumptech.glide.annotation.GlideModule
import com.bumptech.glide.module.AppGlideModule

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description:
 */

@GlideModule
class MyGlideModule : AppGlideModule()