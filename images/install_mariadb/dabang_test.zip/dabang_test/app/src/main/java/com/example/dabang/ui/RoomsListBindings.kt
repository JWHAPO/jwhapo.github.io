package com.example.dabang.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.dabang.R
import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import com.example.dabang.model.Average
import com.example.dabang.model.Room
import com.example.dabang.ui.customview.HashTagTextView
import com.example.dabang.util.GlideApp


@BindingAdapter(value = ["rooms", "averages"])
fun setRooms(view: RecyclerView, rooms: List<Room>?, averages: List<Average>?) {
    view.adapter?.apply {
        if (this is RoomsAdapter) {
            this.rooms = rooms!!
            this.averages = averages!!
            this.notifyDataSetChanged()
        }
    } ?: run {
        RoomsAdapter(rooms?: arrayListOf(), averages?: arrayListOf()).apply {
            view.addItemDecoration(
                DividerItemDecoration(
                    view.context,
                    LinearLayoutManager.VERTICAL
                )
            )
            view.setHasFixedSize(true)
            view.adapter = this
        }
    }
}

@BindingAdapter(value = ["sellingType", "price"])
fun setSellingTypeAndPrice(view: AppCompatTextView, sellingType: SellingType, price: String) {
    val sellingPrice = "$sellingType  $price"
    view.text = sellingPrice
}

@BindingAdapter("roomType")
fun setRoomTypeAndPrice(view: AppCompatTextView, roomType: RoomType) {
    view.text = roomType.toString()
}

@BindingAdapter("hashTags")
fun addHashTags(view: LinearLayoutCompat, hashTags: List<String>) {
    view.removeAllViews()

    for(index in hashTags.indices){
        if(index>3) return

        val textView: TextView = makeHashTagTextView(view.context)
        textView.text = if(index==3) "..." else hashTags[index]
        view.addView(textView)
    }
}

private fun makeHashTagTextView(context: Context): TextView{
    val textView = TextView(context)

    val hashTagColor: Int = ContextCompat.getColor(context, R.color.roomItemHashTagTextColor)
    val hashTagBackground: Drawable? = ContextCompat.getDrawable(context, R.drawable.item_hash_tag_background)
    val textSize: Float = context.resources.getDimension(R.dimen.roomItemHashTagTextSize)
    val padding: Int = context.resources.getDimensionPixelOffset(R.dimen.hashTagTextPadding)
    val margin: Int = context.resources.getDimensionPixelOffset(R.dimen.hashTagMargin)
    val llp: LinearLayoutCompat.LayoutParams = LinearLayoutCompat.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT)

    textView.background = hashTagBackground
    textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize)
    textView.setTextColor(hashTagColor)
    textView.setPadding(padding)
    llp.setMargins(0,0,margin,0)
    textView.layoutParams = llp

    return textView
}

@BindingAdapter("roomImage")
fun setRoomImage(view: ImageView, imageUrl: String){
    GlideApp.with(view.context)
        .load(imageUrl)
        .placeholder(R.drawable.item_image_background)
        .into(view)
}

@BindingAdapter("isCheckImage")
fun isCheckImage(view: ImageView, isCheck: Boolean){
    if(Build.VERSION.SDK_INT < 21){
        if(isCheck) view.setImageResource(R.drawable.ic_like_star)
        else view.setImageResource(R.drawable.ic_unlike_star)
    }else{
        if(isCheck) view.setImageDrawable(view.context.getDrawable(R.drawable.ic_like_star))
        else view.setImageDrawable(view.context.getDrawable(R.drawable.ic_unlike_star))
    }
}

@BindingAdapter("refreshing")
fun SwipeRefreshLayout.refreshing(visible: Boolean) {
    isRefreshing = visible
}