package com.example.dabang.data

import androidx.lifecycle.MutableLiveData
import com.example.dabang.api.RoomService
import com.example.dabang.model.Average
import com.example.dabang.model.Room
import com.example.dabang.model.RoomSearchResult
import com.example.dabang.util.NotNullMutableLiveData
import io.reactivex.disposables.CompositeDisposable

const val PARSING_PAGE_SIZE = 12

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 검색 레파지토리
 */
class RoomRepository(private val service: RoomService) {

    private var lastRequestedPage = 1
    private val parsingErrors = NotNullMutableLiveData("")
    private var isRequestInProgress = false

    private val disposables = CompositeDisposable()

    private var rooms = MutableLiveData<List<Room>>()
    private var averages = MutableLiveData<List<Average>>()

    private var tempRooms :MutableList<Room> = arrayListOf()
    private var tempAverages :MutableList<Average> = arrayListOf()

    private var totalCount: Int = 0

    fun searchRooms(roomTypes: Array<RoomType>, sellingTypes: Array<SellingType>): RoomSearchResult{

        resetState()
        lastRequestedPage = 1

        getTotalCount(roomTypes, sellingTypes)
        requestRoomsData(roomTypes, sellingTypes)

        return RoomSearchResult(averages, rooms, parsingErrors)
    }

    fun requestMore(roomTypes: Array<RoomType>, sellingTypes: Array<SellingType>){
        requestRoomsData(roomTypes, sellingTypes)
    }

    private fun requestRoomsData(roomTypes: Array<RoomType>, sellingTypes: Array<SellingType>){
        if(isRequestInProgress || (tempRooms.size+tempAverages.size) >= totalCount) return
        isRequestInProgress = true

        disposables.add(
            service.searchRooms(roomTypes, sellingTypes, lastRequestedPage, PARSING_PAGE_SIZE)
                .subscribe({
                    tempRooms.addAll(it.rooms)
                    if(lastRequestedPage==1){
                        tempAverages.addAll(it.average)
                        if(tempRooms.size>0) tempRooms.add(Room())
                    }

                    rooms.postValue(tempRooms)
                    averages.postValue(tempAverages)

                    lastRequestedPage++
                    isRequestInProgress = false
                },{
                    parsingErrors.postValue(it.toString())
                    isRequestInProgress = false
                })
        )
        disposables.dispose()
    }

    private fun getTotalCount(roomTypes: Array<RoomType>, sellingTypes: Array<SellingType>){
        disposables.add(
            service.getTotalCount(roomTypes, sellingTypes)
                .subscribe({
                    totalCount = it
                },{
                    totalCount = 0
                })
        )
    }

    private fun resetState(){
        rooms.value = arrayListOf()
        averages.value = arrayListOf()
        tempRooms.clear()
        tempAverages.clear()
    }

}