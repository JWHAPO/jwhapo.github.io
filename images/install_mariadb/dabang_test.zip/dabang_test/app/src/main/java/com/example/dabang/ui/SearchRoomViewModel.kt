package com.example.dabang.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.Transformations
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.dabang.data.RoomFilters
import com.example.dabang.data.RoomRepository
import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import com.example.dabang.model.Average
import com.example.dabang.model.Room
import com.example.dabang.model.RoomSearchResult
import com.example.dabang.ui.base.BaseViewModel
import com.example.dabang.util.NotNullMutableLiveData

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방정보 view model
 */
class SearchRoomViewModel(private val roomRepository: RoomRepository) : BaseViewModel() {

    private val _filters: NotNullMutableLiveData<RoomFilters> = NotNullMutableLiveData(RoomFilters(RoomType.values(), SellingType.values()))
    val filters: NotNullMutableLiveData<RoomFilters>
        get() = _filters

    private val roomSearchResult: LiveData<RoomSearchResult> = Transformations.map(_filters){
        roomRepository.searchRooms(it.roomFilters, it.sellingFilters)
    }

    private val _rooms: LiveData<List<Room>> = Transformations.switchMap(roomSearchResult){ it.rooms }
    val rooms: LiveData<List<Room>>
        get() = _rooms

    private val _averages: LiveData<List<Average>> = Transformations.switchMap(roomSearchResult){ it.averages }
    val averages: LiveData<List<Average>>
        get() = _averages

    private val _parsingErrors: LiveData<String> = Transformations.switchMap(roomSearchResult){ it.parsingErrors }
    val parsingErrors: LiveData<String>
        get() = _parsingErrors

    private val _refreshing: NotNullMutableLiveData<Boolean> = NotNullMutableLiveData(false)
    val refreshing: NotNullMutableLiveData<Boolean>
        get() = _refreshing

    fun setRoomFilters(roomTypes: Array<RoomType>){
        _filters.postValue(RoomFilters(roomTypes, _filters.value.sellingFilters))
    }

    fun setSellingFilters(sellingTypes: Array<SellingType>){
        _filters.postValue(RoomFilters(_filters.value.roomFilters, sellingTypes))
    }

    private fun searchRooms(){
        _filters.postValue(RoomFilters(_filters.value.roomFilters, _filters.value.sellingFilters))
        disappearRefreshProgress()
    }

    private fun disappearRefreshProgress(){
        _refreshing.value = false
    }

    fun onRefreshListener() : SwipeRefreshLayout.OnRefreshListener =
        SwipeRefreshLayout.OnRefreshListener {
            searchRooms()
        }

    fun onScrollListener() : RecyclerView.OnScrollListener {
        return object : RecyclerView.OnScrollListener(){
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val totalItemCount = (recyclerView.layoutManager as LinearLayoutManager).itemCount
                val lastVisibleItemPosition = (recyclerView.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
                if (lastVisibleItemPosition + VISIBLE_THRESHOLD >= totalItemCount) {
                    roomRepository.requestMore(_filters.value.roomFilters, _filters.value.sellingFilters)
                }
            }
        }
    }
    companion object {
        private const val VISIBLE_THRESHOLD = 5
    }
}