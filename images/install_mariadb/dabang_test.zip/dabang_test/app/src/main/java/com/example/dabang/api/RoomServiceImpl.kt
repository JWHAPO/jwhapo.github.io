package com.example.dabang.api

import android.content.Context
import com.example.dabang.data.RoomType
import com.example.dabang.data.SellingType
import com.example.dabang.util.getJsonStringFromAssetFile
import com.google.gson.Gson
import io.reactivex.Single

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 검색 서비스 구현체
 */
class RoomServiceImpl(private val context: Context) : RoomService {
    private var gson: Gson = Gson()

    override fun searchRooms(
        roomTypes: Array<RoomType>,
        sellingTypes: Array<SellingType>,
        page: Int,
        perPage: Int
    ): Single<RoomSearchResponse> {

        val jsonString: String = getJsonStringFromAssetFile(context, "rooms.json")
        val roomSearchResponse: RoomSearchResponse =
            gson.fromJson(jsonString, RoomSearchResponse::class.java)

        roomSearchResponse.rooms =
            roomSearchResponse.rooms
                .filter { rooms ->
                    roomTypes.contains(rooms.room_type) && sellingTypes.contains(rooms.selling_type)
                }
                .filterIndexed { i, _ ->
                    (i >= (page - 1) * perPage) && (i < page * perPage)
                }

        return Single.just(roomSearchResponse)
    }

    override fun getTotalCount(
        roomTypes: Array<RoomType>,
        sellingTypes: Array<SellingType>
    ): Single<Int> {

        val jsonString: String = getJsonStringFromAssetFile(context, "rooms.json")
        val roomSearchResponse: RoomSearchResponse =
            gson.fromJson(jsonString, RoomSearchResponse::class.java)

        roomSearchResponse.rooms =
            roomSearchResponse.rooms
                .filter { rooms ->
                    roomTypes.contains(rooms.room_type) && sellingTypes.contains(rooms.selling_type)
                }

        return Single.just(roomSearchResponse.rooms.size + roomSearchResponse.average.size)
    }
}