package com.example.dabang.ui.customview

import android.content.Context
import android.content.res.TypedArray
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View.OnClickListener
import androidx.appcompat.widget.AppCompatButton
import androidx.constraintlayout.widget.ConstraintLayout
import com.example.dabang.R
import com.example.dabang.data.RoomType
import com.example.dabang.ui.SearchRoomViewModel
import com.example.dabang.ui.base.BaseViewModel
import com.example.dabang.util.style.CheckedFilterButtonStyleHolder
import com.example.dabang.util.style.StyleHolder
import com.example.dabang.util.style.UnCheckedFilterButtonStyleHolder


/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방종류 layout custom view
 */
class RoomFilterView constructor(context: Context, attrs: AttributeSet) :
    ConstraintLayout(context, attrs) {
    private val filterRoomTypeOneRoomBtn: AppCompatButton
    private val filterRoomTypeTwoRoomBtn: AppCompatButton
    private val filterRoomTypeOfficetelBtn: AppCompatButton
    private val filterRoomTypeAptBtn: AppCompatButton
    private val checkedFilterButtonStyleHolder: StyleHolder<AppCompatButton> = CheckedFilterButtonStyleHolder(context)
    private val unCheckedFilterButtonStyleHolder: StyleHolder<AppCompatButton> = UnCheckedFilterButtonStyleHolder(context)

    private lateinit var searchRoomViewModel: SearchRoomViewModel

    init {
        val layoutInflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = layoutInflater.inflate(R.layout.custom_room_filter_view, this, false)
        addView(view)

        filterRoomTypeOneRoomBtn = findViewById(R.id.filter_room_type_one_room_btn)
        filterRoomTypeTwoRoomBtn = findViewById(R.id.filter_room_type_two_room_btn)
        filterRoomTypeOfficetelBtn = findViewById(R.id.filter_room_type_officetel_btn)
        filterRoomTypeAptBtn = findViewById(R.id.filter_room_type_apt_btn)

        initListener()
        getAttrs(attrs)
    }

    private fun initListener() {
        filterRoomTypeOneRoomBtn.setOnClickListener(onClickListener())
        filterRoomTypeTwoRoomBtn.setOnClickListener(onClickListener())
        filterRoomTypeOfficetelBtn.setOnClickListener(onClickListener())
        filterRoomTypeAptBtn.setOnClickListener(onClickListener())
    }

    private fun onClickListener(): OnClickListener {
        return OnClickListener { view ->
            when (view.id) {
                R.id.filter_room_type_one_room_btn -> changeRoomFilter(RoomType.ONE, filterRoomTypeOneRoomBtn)
                R.id.filter_room_type_two_room_btn -> changeRoomFilter(RoomType.TWO,filterRoomTypeTwoRoomBtn)
                R.id.filter_room_type_officetel_btn -> changeRoomFilter(RoomType.OFFICETEL,filterRoomTypeOfficetelBtn)
                R.id.filter_room_type_apt_btn -> changeRoomFilter(RoomType.APT, filterRoomTypeAptBtn)
            }
        }
    }

    private fun changeRoomFilter(roomType: RoomType, button: AppCompatButton) {
        val roomTypes: Array<RoomType> = this.searchRoomViewModel.filters.value.roomFilters

        if (roomTypes.contains(roomType)) {
            if(roomTypes.size == 1) return

            unCheckedFilterButtonStyleHolder.applyStyle(button)
            this.searchRoomViewModel.setRoomFilters(roomTypes.filter { it != roomType }.toTypedArray())
        } else {
            checkedFilterButtonStyleHolder.applyStyle(button)
            this.searchRoomViewModel.setRoomFilters(roomTypes.plus(roomType))
        }
    }

    private fun getAttrs(attrs: AttributeSet) {
        val typedArray: TypedArray = context.theme.obtainStyledAttributes(
            attrs,
            R.styleable.RoomFilterView, 0, 0
        )
        setTypedArray(typedArray)
    }

    private fun setTypedArray(typedArray: TypedArray) {
        typedArray.recycle()
    }

    fun setRoomTypes(viewModel: BaseViewModel) {
        if(viewModel is SearchRoomViewModel) this.searchRoomViewModel = viewModel
    }

}