package com.example.dabang.model

import com.google.gson.annotations.SerializedName

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 평균가격 정보
 */
data class Average(
    @field:SerializedName("monthPrice") val monthPrice: String,
    @field:SerializedName("name") val name: String,
    @field:SerializedName("yearPrice") val yearPrice: String
)