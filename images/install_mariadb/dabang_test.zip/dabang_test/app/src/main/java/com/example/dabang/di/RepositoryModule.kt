package com.example.dabang.di

import com.example.dabang.data.RoomRepository
import org.koin.dsl.module

val repositoryModule = module {
    single(createdAtStart = false) { RoomRepository(get())}
}