package com.example.dabang.ui.base

import android.view.View
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.RecyclerView

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description:
 */
abstract class BaseViewHolder<out T : ViewDataBinding>(view: View) : RecyclerView.ViewHolder(view) {
    val viewDataBinding: T = DataBindingUtil.bind(view)!!
}