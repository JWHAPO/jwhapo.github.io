package com.example.dabang.api

import com.example.dabang.model.Average
import com.example.dabang.model.Room
import com.google.gson.annotations.SerializedName

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방 정보 검색시 받는 데이터
 */
data class RoomSearchResponse(
    @field:SerializedName("average") val average: List<Average>,
    @field:SerializedName("rooms") var rooms: List<Room>
)