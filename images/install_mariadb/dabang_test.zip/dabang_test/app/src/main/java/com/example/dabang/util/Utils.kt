package com.example.dabang.util

import android.content.Context
import java.io.InputStream
import java.nio.charset.Charset

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description:
 */

fun getJsonStringFromAssetFile(context: Context, fileName: String) : String{
    val inputStream: InputStream = context.assets.open(fileName)
    val fileSize: Int = inputStream.available()

    val buffer = ByteArray(fileSize)
    inputStream.read(buffer)
    inputStream.close()

    return String(buffer, Charset.forName("UTF-8"))
}