package com.example.dabang.data

import com.example.dabang.MainApplication
import com.example.dabang.R
import com.google.gson.annotations.SerializedName

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 매물 종류
 */
enum class SellingType(private val stringResourceId: Int) {
    @SerializedName("0") MONTH(R.string.selling_type_0),
    @SerializedName("1") YEAR(R.string.selling_type_1),
    @SerializedName("2") SELL(R.string.selling_type_2);

    override fun toString(): String {
        return MainApplication.instance.applicationContext.getString(stringResourceId)
    }

}