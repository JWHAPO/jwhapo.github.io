package com.example.dabang.di

import com.example.dabang.ui.SearchRoomViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description:
 */
val viewModelModule = module {
    viewModel {
        SearchRoomViewModel(get())
    }
}