package com.example.dabang.ui

import com.example.dabang.BR
import com.example.dabang.R
import com.example.dabang.databinding.ActivitySearchRoomBinding
import com.example.dabang.ui.base.BaseActivity
import org.koin.androidx.viewmodel.ext.android.viewModel

/**
 * Created by JEONGWOOKIM on 2020-03-06.
 * Description: 방정보 리스트 activity
 */
class SearchRoomActivity : BaseActivity<ActivitySearchRoomBinding, SearchRoomViewModel>() {

    private val searchRoomViewModel: SearchRoomViewModel by viewModel()

    override fun getLayoutId(): Int = R.layout.activity_search_room

    override fun getBindingVariable(): Int = BR.vm

    override fun getViewModel(): SearchRoomViewModel = searchRoomViewModel

    override fun init() {

    }

}