
# Project Summary

Assets의 json 파일을 파싱하여 Recycler View 구현.   
상단의 Filter를 이용하여 List 변화되도록 구현.   
View Type에 따른 리스트의 아이템 변경.   


# Tech/framework used
* Kotlin
* MVVM with AAC
* Data Binding
* Gson
* Rxjava
* Koin
* Custom View